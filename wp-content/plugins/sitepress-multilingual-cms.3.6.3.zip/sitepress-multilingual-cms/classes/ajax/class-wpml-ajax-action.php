<?php

interface IWPML_Ajax_Action {
	function run();
}